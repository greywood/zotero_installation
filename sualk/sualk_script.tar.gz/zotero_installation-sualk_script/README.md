zotero_installation
===================

installation script for zotero dataserver

It automates the installation steps provided by sualk in his github repository for the zotero data server.
